
## 1. ¿Cual es el objetivo de su módulo?
Llevar un control eficiente y preciso del servicio de transporte hacia el cliente
## 2. ¿A quién beneficia el funcionamiento de su módulo (área interna, cliente - persona o empresa)?
Beneficia al cliente
## 3. ¿Qué resultado genera su módulo? ¿Es un producto o un servicio? ¿Qué características tiene?
Es un servicio digital que se encarga de generan ordenes de transporte, informes de entrega y reportes de incidentes
## 4. ¿Qué recursos se emplean para obtener dicho resultado?
Un gestor de base de datos, personal humano, gps.
## 5. ¿Cómo se planifican el uso de estos recursos?
Se establecen políticas de transporte y seguimiento de estos.
## 6. ¿Cómo se reserva el uso / la propiedad del producto o servicio generado?
Supervisor de transporte, Transportista.




